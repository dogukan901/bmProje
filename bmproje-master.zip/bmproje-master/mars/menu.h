#ifndef MENU_H
#define MENU_H

void add_listing();
void remove_listing();
void list_listing();
void edit_listing();
void search_listing();

#endif // !MENU_H


