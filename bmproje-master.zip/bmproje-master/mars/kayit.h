#ifndef KAYIT_H
#define KAYIT_H



void login();
void signin();




#endif // !_KAYIT_H
