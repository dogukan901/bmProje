#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include "kayit.h"
FILE* fperm, * ftemp;
struct member {
	int id, state;
	char name[15];
	char surname[15];
};


void login() {

}
void signin() {
	/*
	int id;
	fperm= fopen("C:\Users\berk_\OneDrive\Masa�st�\mars\.vs","r");
	printf("Enter your identity number");
	scanf_s("%d",);//

	while (fscanf_s(fperm, "%d     %s     %s     %d", &member)) {


	}*/
}

